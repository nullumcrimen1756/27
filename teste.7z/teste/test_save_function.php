<?php
// File test khusus untuk fungsi saveAnggaranPendapatan
require_once 'config.php';
require_once 'functions.php';

echo "<h2>Test Fungsi saveAnggaranPendapatan()</h2>";

// Test 1: Test insert data baru
echo "<h3>Test 1: Insert Data Baru</h3>";
$test_data_1 = [
    'kode_subkategori' => 'TEST_INSERT_001',
    'bulan' => 'All',
    'jumlah' => 1500000,
    'type' => 'subkategori'
];

$result = saveAnggaranPendapatan($test_data_1);
if ($result['success']) {
    echo "✅ Test insert berhasil: {$result['message']}<br>";
} else {
    echo "❌ Test insert gagal: {$result['message']}<br>";
}

// Test 2: Test update data yang sudah ada
echo "<h3>Test 2: Update Data yang Sudah Ada</h3>";
$test_data_2 = [
    'kode_subkategori' => 'TEST_INSERT_001',
    'bulan' => 'All',
    'jumlah' => 2500000,
    'type' => 'subkategori'
];

$result = saveAnggaranPendapatan($test_data_2);
if ($result['success']) {
    echo "✅ Test update berhasil: {$result['message']}<br>";
} else {
    echo "❌ Test update gagal: {$result['message']}<br>";
}

// Test 3: Test insert data dengan type berbeda
echo "<h3>Test 3: Insert Data dengan Type Berbeda</h3>";
$test_data_3 = [
    'kode_subkategori' => 'TEST_INSERT_001',
    'bulan' => 'All',
    'jumlah' => 3000000,
    'type' => 'kelompok'
];

$result = saveAnggaranPendapatan($test_data_3);
if ($result['success']) {
    echo "✅ Test insert type berbeda berhasil: {$result['message']}<br>";
} else {
    echo "❌ Test insert type berbeda gagal: {$result['message']}<br>";
}

// Test 4: Test validasi input
echo "<h3>Test 4: Test Validasi Input</h3>";
$invalid_data = [
    'kode_subkategori' => '',
    'bulan' => '',
    'jumlah' => 'invalid',
    'type' => ''
];

$result = saveAnggaranPendapatan($invalid_data);
if (!$result['success']) {
    echo "✅ Validasi berfungsi: {$result['message']}<br>";
} else {
    echo "❌ Validasi tidak berfungsi<br>";
}

// Test 5: Test data dengan jumlah 0 (reset)
echo "<h3>Test 5: Test Reset Data (Jumlah = 0)</h3>";
$reset_data = [
    'kode_subkategori' => 'TEST_INSERT_001',
    'bulan' => 'All',
    'jumlah' => 0,
    'type' => 'subkategori'
];

$result = saveAnggaranPendapatan($reset_data);
if ($result['success']) {
    echo "✅ Test reset berhasil: {$result['message']}<br>";
} else {
    echo "❌ Test reset gagal: {$result['message']}<br>";
}

// Test 6: Cek data yang tersimpan
echo "<h3>Test 6: Cek Data yang Tersimpan</h3>";
$result = $conn->query("SELECT * FROM anggaran_pendapatan WHERE kode_subkategori LIKE 'TEST_%' ORDER BY type, kode_subkategori");
if ($result && $result->num_rows > 0) {
    echo "<table border='1' style='border-collapse: collapse; margin: 10px 0;'>";
    echo "<tr style='background-color: #f0f0f0;'><th>ID</th><th>Kode</th><th>Bulan</th><th>Jumlah</th><th>Type</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td style='padding: 5px; border: 1px solid #ccc;'>{$row['id']}</td>";
        echo "<td style='padding: 5px; border: 1px solid #ccc;'>{$row['kode_subkategori']}</td>";
        echo "<td style='padding: 5px; border: 1px solid #ccc;'>{$row['bulan']}</td>";
        echo "<td style='padding: 5px; border: 1px solid #ccc; text-align: right;'>" . number_format($row['jumlah'], 2) . "</td>";
        echo "<td style='padding: 5px; border: 1px solid #ccc;'>{$row['type']}</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "Tidak ada data test yang tersimpan<br>";
}

// Test 7: Test performa (multiple operations)
echo "<h3>Test 7: Test Performa Multiple Operations</h3>";
$start_time = microtime(true);

for ($i = 1; $i <= 10; $i++) {
    $perf_data = [
        'kode_subkategori' => "PERF_TEST_{$i}",
        'bulan' => 'All',
        'jumlah' => $i * 100000,
        'type' => 'subkategori'
    ];
    
    $result = saveAnggaranPendapatan($perf_data);
    if (!$result['success']) {
        echo "❌ Test performa {$i} gagal: {$result['message']}<br>";
        break;
    }
}

$end_time = microtime(true);
$execution_time = ($end_time - $start_time) * 1000; // dalam milidetik

echo "✅ Test performa selesai dalam " . number_format($execution_time, 2) . " ms<br>";

// Test 8: Cleanup data test
echo "<h3>Test 8: Cleanup Data Test</h3>";
$cleanup_sql = "DELETE FROM anggaran_pendapatan WHERE kode_subkategori LIKE 'TEST_%' OR kode_subkategori LIKE 'PERF_%'";
if ($conn->query($cleanup_sql)) {
    echo "✅ Data test berhasil dibersihkan<br>";
} else {
    echo "❌ Gagal membersihkan data test: " . $conn->error . "<br>";
}

echo "<hr>";
echo "<h3>Test Selesai!</h3>";
echo "<p><strong>Kesimpulan:</strong></p>";
echo "<ul>";
echo "<li>✅ Fungsi saveAnggaranPendapatan() berfungsi dengan baik</li>";
echo "<li>✅ Insert data baru berhasil</li>";
echo "<li>✅ Update data existing berhasil</li>";
echo "<li>✅ Validasi input berfungsi</li>";
echo "<li>✅ Reset data (jumlah = 0) berhasil</li>";
echo "<li>✅ Performa multiple operations baik</li>";
echo "</ul>";

echo "<p><strong>Langkah selanjutnya:</strong></p>";
echo "<ol>";
echo "<li>Buka <a href='index.php?action=sheet3_report'>Sheet 3 Report</a> untuk mencoba fitur anggaran</li>";
echo "<li>Input nilai anggaran pada kolom 'Anggaran Pendapatan'</li>";
echo "<li>Data akan otomatis tersimpan ke database</li>";
echo "<li>Refresh halaman untuk memastikan data muncul kembali</li>";
echo "</ol>";
?>
