<?php
// get_subcodes.php
require_once 'config.php';

// Enable CORS if needed
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

$kategori_id = isset($_GET['kategori_id']) ? intval($_GET['kategori_id']) : 0;
$jurnal_id = isset($_GET['jurnal_id']) ? intval($_GET['jurnal_id']) : 0;

$existing_subcodes = [];

error_log("get_subcodes.php called with kategori_id: $kategori_id, jurnal_id: $jurnal_id");

try {
    if ($kategori_id > 0) {
        // Ambil subcodes yang sudah ada untuk kategori tertentu
        $sql = "SELECT DISTINCT SUBSTRING(kode_subkategori, 5, 2) as subcode 
                FROM subkategori 
                WHERE id_kategori = ? 
                AND kode_subkategori REGEXP '^[0-9]{3}\\.[0-9]{2}$'
                ORDER BY subcode";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $kategori_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while($row = $result->fetch_assoc()) {
            $existing_subcodes[] = $row['subcode'];
        }
        
        error_log("Found " . count($existing_subcodes) . " subcodes for kategori $kategori_id");
        
    } elseif ($jurnal_id > 0) {
        // Ambil subcodes yang sudah ada untuk jurnal tertentu
        $sql = "SELECT DISTINCT SUBSTRING(s.kode_subkategori, 5, 2) as subcode 
                FROM subkategori s
                JOIN kategori k ON s.id_kategori = k.id_kategori
                WHERE k.id_jurnal = ? 
                AND s.kode_subkategori REGEXP '^[0-9]{3}\\.[0-9]{2}$'
                ORDER BY subcode";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $jurnal_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while($row = $result->fetch_assoc()) {
            $existing_subcodes[] = $row['subcode'];
        }
        
        error_log("Found " . count($existing_subcodes) . " subcodes for jurnal $jurnal_id");
    }

    echo json_encode(['existing' => $existing_subcodes]);

} catch (Exception $e) {
    error_log("Error in get_subcodes.php: " . $e->getMessage());
    echo json_encode(['error' => $e->getMessage(), 'existing' => []]);
}

exit;
?>