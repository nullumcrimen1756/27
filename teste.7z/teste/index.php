<?php
require_once 'config.php';
require_once 'functions.php';

session_start();

// Jika belum login, redirect ke halaman login
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

// Set judul halaman
$page_title = "Input Transaksi - Sistem Keuangan Gereja";

$action = isset($_GET['action']) ? $_GET['action'] : 'form';

switch ($action) {
    case 'form':
        showForm();
        break;
    case 'submit':
        submitForm();
        break;
    case 'report':
        $jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : null;
        $tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');
        generateSheet1Report($jurnal_filter, $tahun_filter);
        include 'views/sheet1_report.php';
        break;
    case 'sheet1_report':
        $jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : null;
        $tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');
        generateSheet1Report($jurnal_filter, $tahun_filter);
        include 'views/sheet1_report.php';
        break;
    case 'sheet2_report':
        $jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : null;
        $tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');
        generateSheet2Report($jurnal_filter, $tahun_filter);
        include 'views/sheet2_report.php';
        break;
    case 'sheet3_report':
        $jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : null;
        $tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');
        generateSheet3Report($jurnal_filter, $tahun_filter);
        include 'views/sheet3_report.php';
        break;
    case 'get_kategori':
        getKategoriByJurnal();
        break;
    case 'get_subkategori':
        getSubkategori();
        break;
    default:
        showForm();
}

// Include header
include 'views/header.php';

// ... existing content ...

// Include footer
include 'views/footer.php';
?>