<?php
// Tambahkan filter jurnal di bagian atas laporan
$selected_jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : '';
$selected_tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');
?>

<div class="card mb-4">
    <div class="card-header">
        <h6 class="mb-0">Filter Laporan Sheet 3</h6>
    </div>
    <div class="card-body">
        <form method="get" action="index.php" class="row g-3 align-items-center">
            <input type="hidden" name="action" value="sheet3_report">
            <div class="col-md-4">
                <label for="jurnal_filter" class="form-label">Jurnal:</label>
                <select name="jurnal_filter" id="jurnal_filter" class="form-select" onchange="this.form.submit()">
                    <option value="">Semua Jurnal</option>
                    <?php foreach ($daftar_jurnal as $id => $nama): ?>
                        <option value="<?= $id ?>" <?= ($selected_jurnal_filter == $id) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($nama) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label for="tahun_filter" class="form-label">Tahun:</label>
                <select name="tahun_filter" id="tahun_filter" class="form-select" onchange="this.form.submit()">
                    <?php for ($year = date('Y'); $year >= 2020; $year--): ?>
                        <option value="<?= $year ?>" <?= ($selected_tahun_filter == $year) ? 'selected' : '' ?>>
                            <?= $year ?>
                        </option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">&nbsp;</label><br>
                <a href="index.php?action=sheet3_report" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-clockwise me-1"></i>Reset
                </a>
            </div>
        </form>
    </div>
</div>

<?php
if (!isset($_SESSION['sheet3_report']) || empty($_SESSION['sheet3_report'])) {
    echo "<div class='alert alert-info'>Tidak ada data laporan. Silakan input data terlebih dahulu.</div>";
    return;
}

$report = $_SESSION['sheet3_report'];

// Periksa struktur data yang tersedia
if (!isset($report['bulan']) || !is_array($report['bulan'])) {
    echo "<div class='alert alert-warning'>Struktur data laporan tidak valid.</div>";
    return;
}

// Filter data berdasarkan jurnal yang dipilih
$filtered_categories = [];
$filtered_sub_categories = [];
$filtered_total_kas = [];
$filtered_total_per_kelompok = [];
$filtered_total_per_kategori_bulan = [];

if ($selected_jurnal_filter) {
    // Hanya ambil kategori yang berkaitan dengan jurnal yang dipilih
    if (isset($report['all_categories']) && !empty($report['all_categories'])) {
        foreach ($report['all_categories'] as $kategori) {
            // Cek apakah kategori ini memiliki data untuk jurnal yang dipilih
            $has_data = false;
            foreach ($report['bulan'] as $bulan) {
                $totalKey = $kategori . "|" . $bulan;
                if (isset($report['total_per_kategori_bulan'][$totalKey]) && $report['total_per_kategori_bulan'][$totalKey] > 0) {
                    $has_data = true;
                    break;
                }
            }
            
            if ($has_data) {
                $filtered_categories[] = $kategori;
                if (isset($report['all_sub_categories'][$kategori])) {
                    $filtered_sub_categories[$kategori] = $report['all_sub_categories'][$kategori];
                }
            }
        }
    }
    
    // Filter total_kas hanya untuk kategori yang dipilih
    if (isset($report['total_kas'])) {
        foreach ($report['total_kas'] as $key => $value) {
            $parts = explode('|', $key);
            if (count($parts) >= 2 && in_array($parts[0], $filtered_categories)) {
                $filtered_total_kas[$key] = $value;
            }
        }
    }
    
    // Filter total_per_kelompok hanya untuk kategori yang dipilih
    if (isset($report['total_per_kelompok'])) {
        foreach ($report['total_per_kelompok'] as $key => $value) {
            $parts = explode('|', $key);
            if (count($parts) >= 2) {
                $kelompok = $parts[0];
                // Cek apakah ada kategori dalam kelompok ini yang termasuk dalam filtered_categories
                $has_kategori_in_kelompok = false;
                foreach ($filtered_categories as $kategori) {
                    if (substr($kategori, 0, 3) === $kelompok) {
                        $has_kategori_in_kelompok = true;
                        break;
                    }
                }
                if ($has_kategori_in_kelompok) {
                    $filtered_total_per_kelompok[$key] = $value;
                }
            }
        }
    }
    
    // Filter total_per_kategori_bulan hanya untuk kategori yang dipilih
    if (isset($report['total_per_kategori_bulan'])) {
        foreach ($report['total_per_kategori_bulan'] as $key => $value) {
            $parts = explode('|', $key);
            if (count($parts) >= 2 && in_array($parts[0], $filtered_categories)) {
                $filtered_total_per_kategori_bulan[$key] = $value;
            }
        }
    }
} else {
    // Jika tidak ada filter jurnal, gunakan semua data
    $filtered_categories = $report['all_categories'] ?? [];
    $filtered_sub_categories = $report['all_sub_categories'] ?? [];
    $filtered_total_kas = $report['total_kas'] ?? [];
    $filtered_total_per_kelompok = $report['total_per_kelompok'] ?? [];
    $filtered_total_per_kategori_bulan = $report['total_per_kategori_bulan'] ?? [];
}
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">
            <i class="bi bi-table me-2"></i>Laporan Horizontal (Sheet 3)
            <?php if ($selected_jurnal_filter): ?>
                <span class="badge bg-primary ms-2"><?= htmlspecialchars($daftar_jurnal[$selected_jurnal_filter]) ?></span>
            <?php endif; ?>
            <?php if ($selected_tahun_filter): ?>
                <span class="badge bg-secondary ms-1">Tahun: <?= $selected_tahun_filter ?></span>
            <?php endif; ?>
        </h5>
        <div>
            <button id="exportExcel" class="btn btn-success">
                <i class="bi bi-file-earmark-excel me-1"></i>Ekspor ke Excel
            </button>
        </div>
    </div>
    <div class="card-body">
        <?php if (!empty($filtered_categories)): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="sheet3Table">
                    <thead class="table-dark">
                        <tr>
                            <th>Kode Kategori</th>
                            <th>Subkode</th>
                            <th>KEGIATAN (Level 1)</th>
                            <th>Kode Detail</th>
                            <th>URAIAN KEGIATAN (Level 2)</th>
                            <?php foreach ($report['bulan'] as $bulan): ?>
                                <th class="text-center"><?= htmlspecialchars($bulan) ?></th>
                            <?php endforeach; ?>
                            <th class="text-center">Total</th>
                            <th class="text-center">Anggaran Pendapatan</th>
                            <th class="text-center">Selisih</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $group_totals = array_fill_keys($report['bulan'], 0);
                        $overall_totals = array_fill_keys($report['bulan'], 0);
                        $row_counter = 0;

                        // Bangun peta: kat3 => [kat6...], dan kat6 => [detail...]
                        $map_kat3_to_kat6 = [];
                        $map_kat6_to_details = [];
                        foreach ($filtered_sub_categories as $kat6 => $subsFull) {
                            $kat3 = substr($kat6, 0, 3);
                            if (!isset($map_kat3_to_kat6[$kat3])) $map_kat3_to_kat6[$kat3] = [];
                            if (!in_array($kat6, $map_kat3_to_kat6[$kat3])) $map_kat3_to_kat6[$kat3][] = $kat6;
                            foreach ($subsFull as $codeFull) {
                                $parts = explode('.', $codeFull);
                                if (count($parts) >= 3) {
                                    if (!isset($map_kat6_to_details[$kat6])) $map_kat6_to_details[$kat6] = [];
                                    if (!in_array($codeFull, $map_kat6_to_details[$kat6])) $map_kat6_to_details[$kat6][] = $codeFull;
                                }
                            }
                        }

                        // Helper: sum untuk sekumpulan key
                        $get_total_for_keys = function($keys, $bulan) use ($filtered_total_kas) {
                            $sum = 0;
                            foreach ($keys as $k) {
                                $sum += isset($filtered_total_kas[$k]) ? $filtered_total_kas[$k] : 0;
                            }
                            return $sum;
                        };
                        ?>

                        <!-- Uang Setoran di awal jika ada -->
                        <?php if (!empty($report['uang_setoran'])): ?>
                            <?php $totalUangSetoran = 0; ?>
                            <tr style="background-color: #c8ffc8;" class="uang-setoran-row" data-row="<?= $row_counter++ ?>">
                                <td>Uang Setoran</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <?php foreach ($report['bulan'] as $bulan): 
                                    $amount = isset($report['uang_setoran'][$bulan]) ? $report['uang_setoran'][$bulan] : 0;
                                    $totalUangSetoran += $amount;
                                    $overall_totals[$bulan] += $amount;
                                ?>
                                    <td class="text-end">Rp <?= number_format($amount, 0, ',', '.') ?></td>
                                <?php endforeach; ?>
                                <td class="text-end fw-bold">Rp <?= number_format($totalUangSetoran, 0, ',', '.') ?></td>
                                <td class="text-center">
                                    <input type="number" class="form-control form-control-sm anggaran-input" 
                                           data-row="<?= $row_counter-1 ?>" 
                                           data-type="uang-setoran" 
                                           placeholder="0" 
                                           step="0.01" 
                                           min="0"
                                           value="<?= isset($report['anggaran_dict']['UANG_SETORAN|All|uang-setoran']) ? 
                                                   $report['anggaran_dict']['UANG_SETORAN|All|uang-setoran'] : '' ?>">
                                </td>
                                <td class="text-end fw-bold selisih-cell" data-row="<?= $row_counter-1 ?>">
                                    Rp <?= number_format($totalUangSetoran, 0, ',', '.') ?>
                                </td>
                            </tr>
                        <?php endif; ?>

                        <?php
                        $kat3_list = array_keys($map_kat3_to_kat6);
                        sort($kat3_list);
                        foreach ($kat3_list as $kat3):
                            $kat6_list = $map_kat3_to_kat6[$kat3];
                            sort($kat6_list);

                            // Precompute total per bulan untuk kategori 3-digit
                            $kategori_total_per_bulan = array_fill_keys($report['bulan'], 0);
                            $sub_rows = [];
                            foreach ($kat6_list as $kat6) {
                                $subcode2 = substr($kat6, 4, 2);
                                $detail_list = isset($map_kat6_to_details[$kat6]) ? $map_kat6_to_details[$kat6] : [];

                                $sub_sums = [];
                                $sub_total_all = 0;
                                foreach ($report['bulan'] as $bulan) {
                                    $keys = [];
                                    $keys[] = $kat6.'|'.$kat6.'|'.$bulan; // level 6 langsung
                                    foreach ($detail_list as $dfull) {
                                        $keys[] = $kat6.'|'.$dfull.'|'.$bulan; // level detail
                                    }
                                    $val = $get_total_for_keys($keys, $bulan);
                                    $sub_sums[$bulan] = $val;
                                    $sub_total_all += $val;
                                    $kategori_total_per_bulan[$bulan] += $val;
                                }

                                // Simpan untuk render
                                $sub_rows[] = [
                                    'kat6' => $kat6,
                                    'subcode2' => $subcode2,
                                    'detail_list' => $detail_list,
                                    'sums' => $sub_sums,
                                    'total' => $sub_total_all,
                                ];
                            }

                            // Render baris kategori 3-digit
                            $kategori_total_all = 0;
                            ?>
                            <tr data-row="<?= $row_counter++ ?>" class="kategori-row">
                                <td class="fw-bold"><?= htmlspecialchars($kat3) ?></td>
                                <td class="fw-bold"></td>
                                <td class="fw-bold"><?= isset($report['uraian_dict'][$kat3]) ? htmlspecialchars($report['uraian_dict'][$kat3]) : '' ?></td>
                                <td class="fw-bold"></td>
                                <td class="fw-bold"></td>
                                <?php foreach ($report['bulan'] as $bulan): 
                                    $amount = $kategori_total_per_bulan[$bulan] ?? 0; 
                                    $kategori_total_all += $amount; 
                                ?>
                                    <td class="text-end">Rp <?= number_format($amount, 0, ',', '.') ?></td>
                                <?php endforeach; ?>
                                <td class="text-end fw-bold">Rp <?= number_format($kategori_total_all, 0, ',', '.') ?></td>
                                <td class="text-center"></td>
                                <td class="text-end fw-bold selisih-cell"></td>
                            </tr>

                            <?php
                            // Render sub 6-digit dan detail di bawahnya
                            foreach ($sub_rows as $sr):
                                if ($sr['total'] <= 0) continue;
                                $kat6 = $sr['kat6'];
                                $subcode2 = $sr['subcode2'];
                                $detail_list = $sr['detail_list'];
                            ?>
                                <tr class="subkategori-row" data-row="<?= $row_counter++ ?>" data-kategori="<?= $kat6 ?>" data-subkategori="<?= $kat6 ?>">
                                    <td class="fw-bold"><?= htmlspecialchars($kat3) ?></td>
                                    <td class="fw-bold"><?= htmlspecialchars($subcode2) ?></td>
                                    <td class="fw-bold"><?= isset($report['uraian_dict'][$kat3]) ? htmlspecialchars($report['uraian_dict'][$kat3]) : '' ?></td>
                                    <td></td>
                                    <td><?= isset($report['uraian_dict'][$kat6]) ? htmlspecialchars($report['uraian_dict'][$kat6]) : 'Uraian Tidak Diketahui' ?></td>
                                    <?php foreach ($report['bulan'] as $bulan): 
                                        $amount = $sr['sums'][$bulan] ?? 0;
                                        $group_totals[$bulan] += $amount;
                                        $overall_totals[$bulan] += $amount;
                                    ?>
                                        <td class="text-end">Rp <?= number_format($amount, 0, ',', '.') ?></td>
                                    <?php endforeach; ?>
                                    <td class="text-end fw-bold">Rp <?= number_format($sr['total'], 0, ',', '.') ?></td>
                                    <td class="text-center">
                                        <input type="number" class="form-control form-control-sm anggaran-input"
                                               data-row="<?= $row_counter-1 ?>"
                                               data-type="subkategori"
                                               data-kategori="<?= $kat6 ?>"
                                               data-subkategori="<?= $kat6 ?>"
                                               placeholder="0"
                                               step="0.01"
                                               min="0"
                                               value="<?= isset($report['anggaran_dict'][$kat6 . '|All|subkategori']) ?
                                                       $report['anggaran_dict'][$kat6 . '|All|subkategori'] : '' ?>">
                                    </td>
                                    <td class="text-end fw-bold selisih-cell" data-row="<?= $row_counter-1 ?>">
                                        Rp <?= number_format($sr['total'], 0, ',', '.') ?>
                                    </td>
                                </tr>

                                <?php
                                // Render detail
                                sort($detail_list);
                                foreach ($detail_list as $dfull):
                                    $parts = explode('.', $dfull);
                                    $detail_code = $parts[2] ?? '';
                                    $detail_total = 0;
                                ?>
                                    <tr class="detail-row" data-row="<?= $row_counter++ ?>" data-kategori="<?= $kat6 ?>" data-subkategori="<?= $dfull ?>">
                                        <td><?= htmlspecialchars($kat3) ?></td>
                                        <td><?= htmlspecialchars($subcode2) ?></td>
                                        <td><?= isset($report['uraian_dict'][$kat3]) ? htmlspecialchars($report['uraian_dict'][$kat3]) : '' ?></td>
                                        <td><?= htmlspecialchars($detail_code) ?></td>
                                        <td><?= isset($report['uraian_dict'][$dfull]) ? htmlspecialchars($report['uraian_dict'][$dfull]) : (isset($report['uraian_dict'][$kat6]) ? htmlspecialchars($report['uraian_dict'][$kat6]) : 'Uraian Tidak Diketahui') ?></td>
                                        <?php foreach ($report['bulan'] as $bulan): 
                                            $key = $kat6.'|'.$dfull.'|'.$bulan;
                                            $amount = isset($filtered_total_kas[$key]) ? $filtered_total_kas[$key] : 0;
                                            $detail_total += $amount;
                                        ?>
                                            <td class="text-end">Rp <?= number_format($amount, 0, ',', '.') ?></td>
                                        <?php endforeach; ?>
                                        <td class="text-end fw-bold">Rp <?= number_format($detail_total, 0, ',', '.') ?></td>
                                        <td class="text-center">
                                            <input type="number" class="form-control form-control-sm anggaran-input"
                                                   data-row="<?= $row_counter-1 ?>"
                                                   data-type="subkategori"
                                                   data-kategori="<?= $kat6 ?>"
                                                   data-subkategori="<?= $dfull ?>"
                                                   placeholder="0"
                                                   step="0.01"
                                                   min="0"
                                                   value="<?= isset($report['anggaran_dict'][$dfull . '|All|subkategori']) ?
                                                           $report['anggaran_dict'][$dfull . '|All|subkategori'] : '' ?>">
                                        </td>
                                        <td class="text-end fw-bold selisih-cell" data-row="<?= $row_counter-1 ?>">
                                            Rp <?= number_format($detail_total, 0, ',', '.') ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endforeach; // sub_rows ?>

                            <?php
                            // Total per kelompok (3 digit), gunakan akumulasi group_totals saat ini
                            $group_total_all = 0;
                            ?>
                            <tr class="table-warning kelompok-total-row" data-row="<?= $row_counter++ ?>" data-kelompok="<?= $kat3 ?>">
                                <td colspan="5"><strong>Total Kelompok <?= $kat3 ?></strong></td>
                                <?php foreach ($report['bulan'] as $bulan): 
                                    $amount = $group_totals[$bulan] ?? 0;
                                    $group_total_all += $amount;
                                ?>
                                    <td class="text-end fw-bold">Rp <?= number_format($amount, 0, ',', '.') ?></td>
                                <?php endforeach; ?>
                                <td class="text-end fw-bold">Rp <?= number_format($group_total_all, 0, ',', '.') ?></td>
                                <td class="text-center">
                                    <input type="number" class="form-control form-control-sm anggaran-input" 
                                           data-row="<?= $row_counter-1 ?>" 
                                           data-type="kelompok" 
                                           data-kelompok="<?= $kat3 ?>"
                                           placeholder="0" 
                                           step="0.01" 
                                           min="0"
                                           value="<?= isset($report['anggaran_dict'][$kat3 . '|All|kelompok']) ? 
                                                   $report['anggaran_dict'][$kat3 . '|All|kelompok'] : '' ?>">
                                </td>
                                <td class="text-end fw-bold selisih-cell" data-row="<?= $row_counter-1 ?>">
                                    Rp <?= number_format($group_total_all, 0, ',', '.') ?>
                                </td>
                            </tr>
                            <?php $group_totals = array_fill_keys($report['bulan'], 0); // reset untuk kelompok berikutnya ?>
                        <?php endforeach; // kat3 ?>

                        <!-- Total keseluruhan -->
                        <tr class="table-primary total-keseluruhan-row" data-row="<?= $row_counter++ ?>">
                            <td colspan="5"><strong>TOTAL KESELURUHAN</strong></td>
                            <?php 
                            $grand_total = 0;
                            foreach ($report['bulan'] as $bulan): 
                                $amount = $overall_totals[$bulan] ?? 0;
                                $grand_total += $amount;
                            ?>
                                <td class="text-end fw-bold">Rp <?= number_format($amount, 0, ',', '.') ?></td>
                            <?php endforeach; ?>
                            <td class="text-end fw-bold">Rp <?= number_format($grand_total, 0, ',', '.') ?></td>
                            <td class="text-center">
                                <input type="number" class="form-control form-control-sm anggaran-input" 
                                       data-row="<?= $row_counter-1 ?>" 
                                       data-type="keseluruhan" 
                                       placeholder="0" 
                                       step="0.01" 
                                       min="0"
                                       value="<?= isset($report['anggaran_dict']['TOTAL_KESELURUHAN|All|keseluruhan']) ? 
                                               $report['anggaran_dict']['TOTAL_KESELURUHAN|All|keseluruhan'] : '' ?>">
                            </td>
                            <td class="text-end fw-bold selisih-cell" data-row="<?= $row_counter-1 ?>">
                                Rp <?= number_format($grand_total, 0, ',', '.') ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                <i class="bi bi-info-circle me-2"></i>
                Tidak ada data kategori yang tersedia untuk jurnal yang dipilih.
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- SheetJS for Excel export -->
<script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>

<!-- JavaScript untuk perhitungan selisih dan input anggaran -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Fungsi untuk format angka ke format rupiah
    function formatRupiah(angka) {
        return 'Rp ' + new Intl.NumberFormat('id-ID').format(angka);
    }
    
    // Fungsi untuk menghitung selisih
    function hitungSelisih(row) {
        const totalCell = row.querySelector('td:nth-last-child(3)'); // Kolom Total
        const anggaranInput = row.querySelector('.anggaran-input');
        const selisihCell = row.querySelector('.selisih-cell');
        
        if (totalCell && anggaranInput && selisihCell) {
            // Ambil nilai total dari teks, hapus semua karakter non-digit
            const totalText = totalCell.textContent.replace(/[^\d]/g, '');
            const total = parseFloat(totalText) || 0;
            const anggaran = parseFloat(anggaranInput.value) || 0;
            const selisih = total - anggaran;
            
            // Update selisih cell dengan format rupiah
            selisihCell.textContent = formatRupiah(selisih);
            
            // Reset class dan tambahkan warna berdasarkan selisih
            selisihCell.className = 'text-end fw-bold selisih-cell';
            if (selisih > 0) {
                selisihCell.classList.add('text-success');
            } else if (selisih < 0) {
                selisihCell.classList.add('text-danger');
            } else {
                selisihCell.classList.add('text-primary');
            }
            
            console.log(`Row ${row.dataset.row}: Total=${total}, Anggaran=${anggaran}, Selisih=${selisih}`);
        }
    }
    
    // Fungsi untuk menyimpan anggaran ke database
    function simpanAnggaranKeDatabase(data) {
        fetch('api/save_anggaran.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok: ' + response.status);
            }
            return response.json();
        })
        .then(data => {
            if (!data.success) {
                console.error('Gagal menyimpan anggaran:', data.message);
                showNotification('Gagal menyimpan anggaran: ' + data.message, 'error');
            } else {
                console.log('Anggaran berhasil disimpan');
                showNotification('Anggaran berhasil disimpan', 'success');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showNotification('Terjadi kesalahan saat menyimpan: ' + error.message, 'error');
        });
    }

    // Fungsi untuk menampilkan notifikasi
    function showNotification(message, type = 'info') {
        // Buat elemen notifikasi
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
        notification.style.cssText = 'top: 20px; right: 20px; z-index: 1050; min-width: 300px;';
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(notification);
        
        // Hapus otomatis setelah 3 detik
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }
    
    // Event listener untuk input anggaran
    document.addEventListener('input', function(e) {
        if (e.target.classList.contains('anggaran-input')) {
            const row = e.target.closest('tr');
            hitungSelisih(row);
            
            // Ambil data untuk disimpan
            const type = e.target.dataset.type;
            let kode_subkategori = '';
            const bulan = 'All'; // Atau bisa disesuaikan dengan bulan tertentu
            
            switch (type) {
                case 'subkategori':
                    kode_subkategori = e.target.dataset.subkategori || '';
                    break;
                case 'kelompok':
                    kode_subkategori = e.target.dataset.kelompok || '';
                    break;
                case 'uang-setoran':
                    kode_subkategori = 'UANG_SETORAN';
                    break;
                case 'keseluruhan':
                    kode_subkategori = 'TOTAL_KESELURUHAN';
                    break;
            }
            
            const jumlah = parseFloat(e.target.value) || 0;
            
            // Simpan ke database
            simpanAnggaranKeDatabase({
                type: type,
                kode_subkategori: kode_subkategori,
                bulan: bulan,
                jumlah: jumlah
            });
        }
    });
    
    // Event listener untuk double click (reset)
    document.addEventListener('dblclick', function(e) {
        if (e.target.classList.contains('anggaran-input')) {
            if (confirm('Apakah Anda yakin ingin menghapus nilai anggaran ini?')) {
                e.target.value = '';
                hitungSelisih(e.target.closest('tr'));
                
                // Hapus dari database juga
                const type = e.target.dataset.type;
                let kode_subkategori = '';
                const bulan = 'All';
                
                switch (type) {
                    case 'subkategori':
                        kode_subkategori = e.target.dataset.subkategori || '';
                        break;
                    case 'kelompok':
                        kode_subkategori = e.target.dataset.kelompok || '';
                        break;
                    case 'uang-setoran':
                        kode_subkategori = 'UANG_SETORAN';
                        break;
                    case 'keseluruhan':
                        kode_subkategori = 'TOTAL_KESELURUHAN';
                        break;
                }
                
                simpanAnggaranKeDatabase({
                    type: type,
                    kode_subkategori: kode_subkategori,
                    bulan: bulan,
                    jumlah: 0
                });
            }
        }
    });
    
    // Inisialisasi perhitungan selisih untuk semua baris
    document.querySelectorAll('tr[data-row]').forEach(function(row) {
        hitungSelisih(row);
    });
    
    // Tambahkan tooltip untuk instruksi
    const anggaranInputs = document.querySelectorAll('.anggaran-input');
    anggaranInputs.forEach(function(input) {
        input.title = 'Klik untuk input anggaran, Double click untuk hapus';
    });

    // Ekspor ke Excel (SheetJS .xlsx, fallback ke CSV)
    const exportBtn = document.getElementById('exportExcel');
    if (exportBtn) {
        exportBtn.addEventListener('click', function() {
            const originalText = this.innerHTML;
            this.innerHTML = '<i class="bi bi-hourglass-split me-1"></i>Menyiapkan Excel...';
            this.disabled = true;

            try {
                const table = document.getElementById('sheet3Table');
                if (!table) throw new Error('Tabel laporan tidak ditemukan');

                const wb = XLSX.utils.book_new();
                const ws = XLSX.utils.aoa_to_sheet([]);

                // Header informasi
                const jurnalSelect = document.getElementById('jurnal_filter');
                const tahunSelect = document.getElementById('tahun_filter');
                const jurnal = jurnalSelect ? jurnalSelect.options[jurnalSelect.selectedIndex].text : 'Semua Jurnal';
                const tahun = tahunSelect ? tahunSelect.value : '';
                const tanggalEkspor = new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

                const excelData = [];
                excelData.push(['LAPORAN SHEET 3 - LAPORAN HORIZONTAL']);
                excelData.push([`Jurnal: ${jurnal}`]);
                excelData.push([`Tahun: ${tahun}`]);
                excelData.push([`Tanggal Ekspor: ${tanggalEkspor}`]);
                excelData.push([]);

                // Header tabel
                const headers = ['Kode Kategori', 'Subkode', 'Kode Detail', 'KEGIATAN (Level 1)', 'URAIAN KEGIATAN (Level 2)'];
                const bulanHeaders = [];
                const theadTh = table.querySelectorAll('thead th');
                theadTh.forEach(function(th, index) {
                    if (index >= 5 && index < theadTh.length - 3) {
                        bulanHeaders.push(th.textContent.trim());
                    }
                });
                const allHeaders = headers.concat(bulanHeaders, ['Total', 'Anggaran Pendapatan', 'Selisih']);
                excelData.push(allHeaders);

                // Data baris + tipe baris untuk styling
                const rowTypes = [];
                table.querySelectorAll('tbody tr').forEach(function(tr) {
                    const row = [];
                    let rowType = 'normal';
                    if (tr.classList.contains('uang-setoran-row')) rowType = 'uang-setoran';
                    else if (tr.classList.contains('kelompok-total-row')) rowType = 'kelompok-total';
                    else if (tr.classList.contains('total-keseluruhan-row')) rowType = 'total-keseluruhan';
                    else if (tr.classList.contains('subkategori-row')) rowType = 'subkategori';

                    tr.querySelectorAll('td').forEach(function(td, index) {
                        let cellValue = td.textContent.trim();
                        const input = td.querySelector('.anggaran-input');
                        if (input) {
                            cellValue = input.value || '0';
                        }
                        if (index >= 5 && cellValue.includes('Rp')) {
                            cellValue = cellValue.replace('Rp', '').replace(/\./g, '').trim();
                            cellValue = parseFloat(cellValue) || 0;
                        }
                        row.push(cellValue);
                    });

                    excelData.push(row);
                    rowTypes.push(rowType);
                });

                XLSX.utils.sheet_add_aoa(ws, excelData, { origin: 'A1' });

                // Lebar kolom
                const colWidths = [{ wch: 14 }, { wch: 10 }, { wch: 12 }, { wch: 28 }, { wch: 40 }];
                for (let i = 0; i < bulanHeaders.length; i++) colWidths.push({ wch: 16 });
                colWidths.push({ wch: 16 }, { wch: 20 }, { wch: 16 });
                ws['!cols'] = colWidths;

                // Styling sel dasar (jika mendukung)
                const range = XLSX.utils.decode_range(ws['!ref']);
                // Judul di baris 1 (index 0)
                for (let C = range.s.c; C <= range.e.c; ++C) {
                    const ref = XLSX.utils.encode_cell({ c: C, r: 0 });
                    if (!ws[ref]) continue;
                    ws[ref].s = { font: { bold: true, sz: 16 }, alignment: { horizontal: 'center' } };
                }
                // Info baris 2-4
                for (let R = 1; R <= 3; ++R) {
                    for (let C = range.s.c; C <= range.e.c; ++C) {
                        const ref = XLSX.utils.encode_cell({ c: C, r: R });
                        if (!ws[ref]) continue;
                        ws[ref].s = { font: { sz: 12 } };
                    }
                }
                // Header tabel (baris 6, index 5)
                for (let C = range.s.c; C <= range.e.c; ++C) {
                    const ref = XLSX.utils.encode_cell({ c: C, r: 5 });
                    if (!ws[ref]) continue;
                    ws[ref].s = { font: { bold: true, color: { rgb: 'FFFFFF' } }, fill: { fgColor: { rgb: '343A40' } }, alignment: { horizontal: 'center' } };
                }
                // Baris data mulai index 6
                for (let R = 6; R <= range.e.r; ++R) {
                    const rowType = rowTypes[R - 6];
                    for (let C = range.s.c; C <= range.e.c; ++C) {
                        const ref = XLSX.utils.encode_cell({ c: C, r: R });
                        if (!ws[ref]) continue;
                        let style = {};
                        if (rowType === 'uang-setoran') style = { fill: { fgColor: { rgb: 'C8FFC8' } }, font: { bold: true } };
                        else if (rowType === 'kelompok-total') style = { fill: { fgColor: { rgb: 'FFF3CD' } }, font: { bold: true } };
                        else if (rowType === 'total-keseluruhan') style = { fill: { fgColor: { rgb: 'CCE5FF' } }, font: { bold: true, sz: 12 } };
                        if (C >= 3 && typeof ws[ref].v === 'number') style.numFmt = '#,##0';
                        ws[ref].s = { ...(ws[ref].s || {}), ...style };
                    }
                }

                XLSX.utils.book_append_sheet(wb, ws, 'Laporan Sheet 3');

                const tanggal = new Date().toISOString().slice(0, 10);
                let fileName = 'Laporan_Sheet3_' + tanggal;
                if (jurnal && jurnal !== 'Semua Jurnal') fileName += '_' + jurnal.replace(/\s+/g, '_');
                if (tahun) fileName += '_' + tahun;

                XLSX.writeFile(wb, fileName + '.xlsx');
                showNotification('File Excel berhasil diunduh: ' + fileName + '.xlsx', 'success');
            } catch (err) {
                console.error('Gagal mengekspor .xlsx, fallback ke CSV:', err);

                // Fallback ke CSV jika SheetJS gagal
                try {
                    const table = document.getElementById('sheet3Table');
                    const csv = [];
                    const headers = [];
                    table.querySelectorAll('thead th').forEach(function(th) { headers.push(th.textContent.trim()); });
                    csv.push(headers.join(','));
                    table.querySelectorAll('tbody tr').forEach(function(tr) {
                        const row = [];
                        tr.querySelectorAll('td').forEach(function(td, index) {
                            let cellValue = td.textContent.trim();
                            const input = td.querySelector('.anggaran-input');
                            if (input) cellValue = input.value || '0';
                            if (index > 2 && cellValue.includes('Rp')) cellValue = cellValue.replace('Rp', '').replace(/\./g, '').trim();
                            if (cellValue.includes(',')) cellValue = '"' + cellValue + '"';
                            row.push(cellValue);
                        });
                        csv.push(row.join(','));
                    });
                    const csvContent = 'data:text/csv;charset=utf-8,' + csv.join('\n');
                    const encodedUri = encodeURI(csvContent);
                    const link = document.createElement('a');
                    link.setAttribute('href', encodedUri);
                    const tanggal = new Date().toISOString().slice(0, 10);
                    const jurnalSelect = document.getElementById('jurnal_filter');
                    const tahunSelect = document.getElementById('tahun_filter');
                    const jurnal = jurnalSelect ? jurnalSelect.options[jurnalSelect.selectedIndex].text : 'Semua Jurnal';
                    const tahun = tahunSelect ? tahunSelect.value : '';
                    let fileName = 'Laporan_Sheet3_' + tanggal;
                    if (jurnal && jurnal !== 'Semua Jurnal') fileName += '_' + jurnal.replace(/\s+/g, '_');
                    if (tahun) fileName += '_' + tahun;
                    fileName += '.csv';
                    link.setAttribute('download', fileName);
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    showNotification('File CSV berhasil diunduh: ' + fileName, 'success');
                } catch (csvErr) {
                    console.error('Fallback CSV juga gagal:', csvErr);
                    showNotification('Gagal mengekspor ke Excel/CSV: ' + csvErr.message, 'error');
                }
            } finally {
                this.innerHTML = originalText;
                this.disabled = false;
            }
        });
    }
});
</script>

<style>
.anggaran-input {
    width: 100px;
    text-align: center;
    font-size: 0.875rem;
}

.anggaran-input:focus {
    border-color: #007bff;
    box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}

.selisih-cell.text-success {
    color: #28a745 !important;
}

.selisih-cell.text-danger {
    color: #dc3545 !important;
}

.selisih-cell.text-primary {
    color: #007bff !important;
}

/* Hover effect untuk input anggaran */
.anggaran-input:hover {
    background-color: #f8f9fa;
}

/* Responsive table */
@media (max-width: 768px) {
    .anggaran-input {
        width: 80px;
        font-size: 0.8rem;
    }
}

/* CSS untuk notifikasi */
.alert-notification {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 1050;
    min-width: 300px;
    animation: slideIn 0.3s ease-out;
}

@keyframes slideIn {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

/* Animasi loading untuk ikon hourglass saat ekspor */
.bi-hourglass-split {
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
</style>