<?php

// Debug: Tampilkan data jurnal
// echo "<pre style='background:#fff;padding:20px;border:2px solid red;z-index:9999;position:relative'>";
// echo "DEBUG DATA JURNAL:\n";
// print_r($jurnals);
// echo "Jumlah Jurnal: " . count($jurnals) . "\n";
// echo "Query: SELECT * FROM jurnal ORDER BY nama_jurnal\n";
// echo "Error: " . $conn->error . "\n";
// echo "</pre>";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Kategori</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-bg);
        }
        
        .card-container {
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            border: none;
        }
        
        .card-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
        }
        
        .jurnal-filter {
            background-color: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .section-title {
            font-weight: 600;
            color: var(--primary-color);
            border-bottom: 2px solid var(--primary-color);
            padding-bottom: 8px;
            margin-bottom: 15px;
        }
        
        .table th {
            background-color: var(--primary-color);
            color: white;
        }
        
        .btn-add {
            background-color: var(--secondary-color);
            color: white;
        }
        
        .btn-add:hover {
            background-color: #2980b9;
        }
        
        .btn-delete {
            background-color: var(--accent-color);
            color: white;
        }
        
        .btn-delete:hover {
            background-color: #c0392b;
        }
        
        .badge-jurnal {
            background-color: var(--secondary-color);
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="card card-container">
            <div class="card-header">
                <h4 class="mb-0"><i class="bi bi-tags me-2"></i>Manajemen Kategori dan Subkategori</h4>
            </div>
            
            <div class="card-body">
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                                
                <!-- Filter Jurnal -->
                <div class="jurnal-filter mb-4">
                    <form method="get" action="admin_kategori.php">
                        <input type="hidden" name="action" value="list">
                        <div class="row align-items-center">
                            <div class="col-md-6 mb-2">
                            <label for="jurnalDropdown" class="form-label">Filter Berdasarkan Jurnal:</label>
                                <select id="jurnalDropdown" name="id_jurnal" class="form-select" onchange="filterByJurnal()">
                                    <option value="">Semua Jurnal</option>
                                    <?php if (!empty($jurnals) && is_array($jurnals)): ?>
                                        <?php foreach ($jurnals as $jurnal): ?>
                                            <?php if (isset($jurnal['id_jurnal']) && isset($jurnal['kode_jurnal']) && isset($jurnal['nama_jurnal'])): ?>
                                                <option value="<?= $jurnal['id_jurnal'] ?>" 
                                                    <?= (isset($selected_jurnal_id) && $selected_jurnal_id == $jurnal['id_jurnal']) ? 'selected' : '' ?>>
                                                    <?= htmlspecialchars($jurnal['kode_jurnal']) ?> - <?= htmlspecialchars($jurnal['nama_jurnal']) ?>
                                                </option>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <option value="">Data Jurnal Tidak Tersedia</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-2">
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-funnel me-1"></i> Filter
                                </button>
                                <?php if (isset($_GET['id_jurnal'])): ?>
                                    <a href="admin_kategori.php?action=list" class="btn btn-outline-secondary">
                                        <i class="bi bi-x-circle me-1"></i> Reset
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>
                </div>
                                
                <!-- Daftar Kategori -->
                <div class="mb-5">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="section-title">
                            <i class="bi bi-list-ul me-2"></i>Daftar Kategori
                        </h5>
                        <a href="admin_kategori.php?action=add_kategori<?php echo isset($_GET['id_jurnal']) ? '&id_jurnal='.$_GET['id_jurnal'] : ''; ?>" 
                           class="btn btn-add">
                            <i class="bi bi-plus-circle me-1"></i>Tambah Kategori
                        </a>
                    </div>
                    
                    <?php if (empty($kategori)): ?>
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle me-2"></i>Belum ada data kategori
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                                <table id="kategoriTable" class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Kode</th>
                                            <th>Nama Kategori</th>
                                            <th>Jurnal</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php foreach ($kategori as $kat): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($kat['kode_kategori']); ?></td>
                                            <td><?php echo htmlspecialchars($kat['nama_kategori']); ?></td>
                                            <td>
                                                <?php 
                                                $jurnal_name = '';
                                                foreach ($jurnals as $jurnal) {
                                                    if ($jurnal['id_jurnal'] == $kat['id_jurnal']) {
                                                        $jurnal_name = $jurnal['nama_jurnal'];
                                                        break;
                                                    }
                                                }
                                                echo '<span class="badge badge-jurnal bg-primary">'.htmlspecialchars($jurnal_name).'</span>';
                                                ?>
                                            </td>
                                            <td>
                                                <a href="admin_kategori.php?action=delete_kategori&id=<?php echo $kat['id_kategori']; ?>" 
                                                   class="btn btn-sm btn-delete"
                                                   onclick="return confirm('Yakin ingin menghapus kategori ini? Semua subkategori terkait juga akan dihapus.')">
                                                    <i class="bi bi-trash me-1"></i>Hapus
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Daftar Subkategori -->
                <div class="mb-3">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="section-title">
                            <i class="bi bi-list-nested me-2"></i>Daftar Subkategori
                        </h5>
                        <div class="d-flex gap-2">
                            <a href="#kegiatan6Form" class="btn btn-outline-secondary">
                                <i class="bi bi-gear-wide-connected me-1"></i>Atur Kegiatan 6 Digit
                            </a>
                            <a href="admin_kategori.php?action=add_subkategori<?php echo isset($_GET['id_jurnal']) ? '&id_jurnal='.$_GET['id_jurnal'] : ''; ?>" 
                               class="btn btn-add">
                                <i class="bi bi-plus-circle me-1"></i>Tambah Subkategori
                            </a>
                        </div>
                    </div>
                    
                    <?php if (empty($subkategori)): ?>
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle me-2"></i>Belum ada data subkategori
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table id="subkategoriTable" class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Kode</th>
                                        <th>Nama Subkategori</th>
                                        <th>Kegiatan (Sub 6 Digit)</th>
                                        <th>Kategori</th>
                                        <th>Jurnal</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                    <tbody>
                                    <?php 
                                        $mapKeg6 = [];
                                        if (!empty($kegiatan6)) {
                                            foreach ($kegiatan6 as $kg) {
                                                $mapKeg6[$kg['kode_subkategori']] = $kg['nama_subkategori'];
                                            }
                                        }
                                        foreach ($subkategori as $sub): 
                                            $kode = $sub['kode_subkategori'];
                                            $kode6 = preg_match('/^[0-9]{3}\.[0-9]{2}$/', $kode) ? $kode : substr($kode, 0, 6);
                                            $kegiatanNama = isset($mapKeg6[$kode6]) ? $mapKeg6[$kode6] : '-';
                                    ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($sub['kode_subkategori']); ?></td>
                                            <td><?php echo htmlspecialchars($sub['nama_subkategori']); ?></td>
                                            <td><span class="text-muted"><?php echo htmlspecialchars($kode6); ?></span> — <strong><?php echo htmlspecialchars($kegiatanNama); ?></strong></td>
                                            <td><?php echo htmlspecialchars($sub['nama_kategori']); ?></td>
                                            <td>
                                                <span class="badge badge-jurnal bg-primary"><?php echo htmlspecialchars($sub['nama_jurnal']); ?></span>
                                            </td>
                                            <td>
                                                <a href="admin_kategori.php?action=delete_subkategori&id=<?php echo $sub['id_subkategori']; ?>" 
                                                   class="btn btn-sm btn-delete"
                                                   onclick="return confirm('Yakin ingin menghapus subkategori ini?')">
                                                    <i class="bi bi-trash me-1"></i>Hapus
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Kelola Kegiatan (Sub 6 Digit) - Inline -->
                <div class="mb-5" id="kegiatan6Form">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="section-title">
                            <i class="bi bi-gear-wide-connected me-2"></i>Kelola Kegiatan (Sub 6 Digit) per Jurnal
                        </h5>
                    </div>

                    <div class="card mb-3">
                        <div class="card-body">
                            <form method="post" action="admin_kategori.php?action=save_kegiatan" class="row g-3">
                                <input type="hidden" name="id_jurnal" value="<?= isset($_GET['id_jurnal']) ? (int)$_GET['id_jurnal'] : 0 ?>">
                                <input type="hidden" name="id_subkategori" id="id_subkategori" value="">
                                <div class="col-md-3">
                                    <label class="form-label">Kategori (3 digit)</label>
                                    <select name="id_kategori" id="id_kategori" class="form-select" required onchange="loadAvailableSubcodes(this.value, <?= isset($_GET['id_jurnal']) ? (int)$_GET['id_jurnal'] : 0 ?>)">
                                        <option value="">- pilih -</option>
                                        <?php foreach ($kategori as $k): ?>
                                            <option value="<?= (int)$k['id_kategori'] ?>">
                                                <?= htmlspecialchars($k['kode_kategori'] . ' - ' . $k['nama_kategori']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label">Subkode (2 digit)</label>
                                    <select name="subcode2" id="subcode2" class="form-select" required disabled>
                                        <option value="">- pilih kategori dulu -</option>
                                    </select>
                                    <div class="form-text">
                                        <small>Pilih dari yang ada atau buat baru</small>
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <label class="form-label">Nama Kegiatan (Uraian Sub 6)</label>
                                    <input type="text" class="form-control" name="nama_subkategori" id="nama_subkategori" required>
                                    <input type="hidden" name="debug_kode" id="debugKode" value="">
                                    <small class="text-muted" id="previewKode"></small>
                                </div>
                                <div class="col-md-2 d-grid">
                                    <label class="form-label">&nbsp;</label>
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Kode Kategori</th>
                                    <th>Subkode</th>
                                    <th>Kode 6 Digit</th>
                                    <th>Nama Kategori</th>
                                    <th>Nama Kegiatan</th>
                                    <th>Jurnal</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($kegiatan6)): ?>
                                    <?php foreach ($kegiatan6 as $s): 
                                        $kat3 = $s['kode_kategori'];
                                        $subcode2 = substr($s['kode_subkategori'], 4, 2);
                                    ?>
                                        <tr>
                                            <td><strong><?= htmlspecialchars($kat3) ?></strong></td>
                                            <td><strong><?= htmlspecialchars($subcode2) ?></strong></td>
                                            <td><?= htmlspecialchars($s['kode_subkategori']) ?></td>
                                            <td><?= htmlspecialchars($s['nama_kategori']) ?></td>
                                            <td><?= htmlspecialchars($s['nama_subkategori']) ?></td>
                                            <td><span class="badge badge-jurnal bg-primary"><?= htmlspecialchars($s['nama_jurnal']) ?></span></td>
                                            <td>
                                                <button class="btn btn-sm btn-warning" onclick="editKegiatan(<?= (int)$s['id_subkategori'] ?>, <?= (int)$s['id_kategori'] ?>, '<?= htmlspecialchars($subcode2, ENT_QUOTES) ?>', '<?= htmlspecialchars($s['nama_subkategori'], ENT_QUOTES) ?>')">Edit</button>
                                                <a class="btn btn-sm btn-delete" href="admin_kategori.php?action=delete_kegiatan6&id=<?= (int)$s['id_subkategori'] ?>&id_jurnal=<?= isset($_GET['id_jurnal']) ? (int)$_GET['id_jurnal'] : 0 ?>" onclick="return confirm('Hapus kegiatan 6 digit ini?')">Hapus</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="7" class="text-center">Belum ada kegiatan 6 digit untuk jurnal ini.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            </div>
        </div>



        <script>
function filterByJurnal() {
    const jurnalId = document.getElementById('jurnalDropdown').value;
    if (jurnalId) {
        window.location.href = 'admin_kategori.php?id_jurnal=' + encodeURIComponent(jurnalId);
    } else {
        window.location.href = 'admin_kategori.php';
    }
}

function loadAvailableSubcodes(kategoriId, jurnalId) {
    console.log('Loading subcodes for kategori:', kategoriId, 'jurnal:', jurnalId);
    
    if (!kategoriId) {
        document.getElementById('subcode2').innerHTML = '<option value="">- pilih kategori dulu -</option>';
        document.getElementById('subcode2').disabled = true;
        return;
    }

    // Fetch subcodes yang sudah ada untuk kategori ini
    fetch('get_subcodes.php?kategori_id=' + kategoriId + '&jurnal_id=' + jurnalId)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log('Received subcodes:', data);
            const select = document.getElementById('subcode2');
            select.innerHTML = '';
            
            // Tambahkan opsi default
            const defaultOption = document.createElement('option');
            defaultOption.value = '';
            defaultOption.textContent = '- pilih subkode -';
            select.appendChild(defaultOption);
            
            // Tambahkan opsi dari database
            if (data.existing && data.existing.length > 0) {
                const groupExisting = document.createElement('optgroup');
                groupExisting.label = 'Subkode yang sudah ada';
                
                data.existing.forEach(subcode => {
                    const option = document.createElement('option');
                    option.value = subcode;
                    option.textContent = subcode;
                    groupExisting.appendChild(option);
                });
                select.appendChild(groupExisting);
            }
            
            // Tambahkan opsi untuk buat baru
            const groupNew = document.createElement('optgroup');
            groupNew.label = 'Buat subkode baru';
            
            // Generate opsi dari 01 sampai 99
            for (let i = 1; i <= 99; i++) {
                const subcode = i.toString().padStart(2, '0');
                // Skip yang sudah ada
                if (!data.existing || !data.existing.includes(subcode)) {
                    const option = document.createElement('option');
                    option.value = subcode;
                    option.textContent = subcode + ' (baru)';
                    groupNew.appendChild(option);
                }
            }
            select.appendChild(groupNew);
            
            select.disabled = false;
        })
        .catch(error => {
            console.error('Error loading subcodes:', error);
            document.getElementById('subcode2').innerHTML = '<option value="">Error loading subcodes</option>';
        });
}

function editKegiatan(id, kategoriId, subcode, nama) {
    console.log('Editing kegiatan:', id, kategoriId, subcode, nama);
    document.getElementById('id_subkategori').value = id;
    document.getElementById('id_kategori').value = kategoriId;
    document.getElementById('nama_subkategori').value = nama;
    
    // Trigger load subcodes untuk kategori yang dipilih
    const jurnalId = <?= isset($_GET['id_jurnal']) ? (int)$_GET['id_jurnal'] : 0 ?>;
    loadAvailableSubcodes(kategoriId, jurnalId);
    
    // Set nilai subcode setelah dropdown terload
    setTimeout(() => {
        const subcodeSelect = document.getElementById('subcode2');
        if (subcodeSelect) {
            subcodeSelect.value = subcode;
        }
    }, 1000);
    
    // Scroll ke form
    document.getElementById('kegiatan6Form').scrollIntoView();
}

// Debug: preview kode xxx.xx yang akan tersimpan
(function setupKodePreview(){
    const sel = document.getElementById('id_kategori');
    const sub = document.getElementById('subcode2');
    const dbg = document.getElementById('debugKode');
    const pv  = document.getElementById('previewKode');
    
    function extractKat3() {
        const opt = sel?.options[sel.selectedIndex];
        if (!opt) return '';
        const txt = opt.textContent || '';
        const kat3 = txt.split('-')[0].trim().split(' ')[0];
        return /^[0-9]{3}$/.test(kat3) ? kat3 : '';
    }
    
    function update() {
        const kat3 = extractKat3();
        const s2 = (sub?.value || '').trim();
        const kode = (kat3 && /^[0-9]{2}$/.test(s2)) ? (kat3 + '.' + s2) : '';
        if (dbg) dbg.value = kode ? ('Akan generate: ' + kode) : '';
        if (pv)  pv.textContent = kode ? ('Akan generate: ' + kode) : '';
    }
    
    if (sel && sub) {
        sel.addEventListener('change', update);
        sub.addEventListener('change', update);
        update();
    }
})();

// Test function untuk debug
function testOnChange() {
    console.log('onchange triggered!');
    const kategoriSelect = document.getElementById('id_kategori');
    if (kategoriSelect) {
        console.log('Selected value:', kategoriSelect.value);
    }
}
</script>




        <script>
        function filterByJurnal() {
            const jurnalId = document.getElementById('jurnalDropdown').value;
            if (jurnalId) {
                window.location.href = 'admin_kategori.php?id_jurnal=' + encodeURIComponent(jurnalId);
            } else {
                window.location.href = 'admin_kategori.php';
            }
        }

        // Debug: preview kode xxx.xx yang akan tersimpan
        (function setupKodePreview(){
            const sel = document.getElementById('id_kategori');
            const sub = document.getElementById('subcode2');
            const dbg = document.getElementById('debugKode');
            const pv  = document.getElementById('previewKode');
            function extractKat3() {
                const opt = sel?.options[sel.selectedIndex];
                if (!opt) return '';
                const txt = opt.textContent || '';
                const kat3 = txt.split('-')[0].trim().split(' ')[0];
                return /^[0-9]{3}$/.test(kat3) ? kat3 : '';
            }
            function update() {
                const kat3 = extractKat3();
                const s2 = (sub?.value || '').trim();
                const kode = (kat3 && /^[0-9]{2}$/.test(s2)) ? (kat3 + '.' + s2) : '';
                if (dbg) dbg.value = kode ? ('Akan generate: ' + kode) : '';
                if (pv)  pv.textContent = kode ? ('Akan generate: ' + kode) : '';
            }
            if (sel && sub) {
                sel.addEventListener('change', update);
                sub.addEventListener('input', update);
                update();
            }
        })();
        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html> 