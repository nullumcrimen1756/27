<?php
// Aktifkan error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Mulai session
session_start();

require_once 'config.php';
require_once 'functions.php';

// Set judul halaman
$page_title = "Kelola Kategori - Sistem Keuangan Gereja";

// DEBUG: Tampilkan error koneksi jika ada
if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

$action = isset($_GET['action']) ? $_GET['action'] : 'list';

// 1. Ambil semua data jurnal untuk dropdown
// Ganti kode pengambilan data jurnal dengan ini:
$jurnals = [];
$sql = "SELECT * FROM jurnal ORDER BY nama_jurnal";
$result = $conn->query($sql);

if ($result === false) {
    die("Error mengambil data jurnal: " . $conn->error);
}

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $jurnals[] = $row;
    }
} else {
    die("Tabel jurnal kosong. Silakan isi data jurnal terlebih dahulu.");
}

// DEBUG: Tampilkan data jurnal yang diambil
error_log("Data Jurnal: " . print_r($jurnals, true));

// 2. Ambil id_jurnal dari parameter URL
$selected_jurnal_id = isset($_GET['id_jurnal']) ? intval($_GET['id_jurnal']) : null;

switch ($action) {
    case 'add_kategori':
        addKategori();
        break;
    case 'add_subkategori':
        addSubkategori();
        break;
    case 'save_kategori':
        saveKategori();
        break;
    case 'save_subkategori':
        saveSubkategori();
        break;
    case 'delete_kategori':
        deleteKategori();
        break;
    case 'delete_subkategori':
        deleteSubkategori();
        break;
    case 'save_kegiatan':
        saveKegiatan();
        break;
    case 'delete_kegiatan6':
        deleteKegiatan6();
        break;
    default:
        listData();
}
function listData() {
    global $conn, $jurnals, $selected_jurnal_id;
    
    $selected_jurnal = isset($_GET['id_jurnal']) ? intval($_GET['id_jurnal']) : null;
    
    // Ambil data kategori
    $kategori = [];
    $sql = "SELECT * FROM kategori";
    if ($selected_jurnal) {
        $sql .= " WHERE id_jurnal = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $selected_jurnal);
        $stmt->execute();
        $result = $stmt->get_result();
    } else {
        $result = $conn->query($sql);
    }
    if ($result && $result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $kategori[] = $row;
        }
    }
    
    // Ambil data subkategori
    $subkategori = [];
    $sql = "SELECT s.*, k.nama_kategori, j.nama_jurnal 
            FROM subkategori s 
            JOIN kategori k ON s.id_kategori = k.id_kategori
            JOIN jurnal j ON k.id_jurnal = j.id_jurnal";
    if ($selected_jurnal) {
        $sql .= " WHERE k.id_jurnal = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $selected_jurnal);
        $stmt->execute();
        $result = $stmt->get_result();
    } else {
        $result = $conn->query($sql);
    }
    if ($result && $result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $subkategori[] = $row;
        }
    }
    
    // Ambil data kegiatan 6 digit untuk jurnal terpilih (opsional filter)
    $kegiatan6 = [];
    $sql6 = "SELECT s.*, k.kode_kategori, k.nama_kategori, j.nama_jurnal
             FROM subkategori s
             JOIN kategori k ON s.id_kategori = k.id_kategori
             JOIN jurnal j ON k.id_jurnal = j.id_jurnal";
    if ($selected_jurnal) {
        $sql6 .= " WHERE k.id_jurnal = ? AND s.kode_subkategori REGEXP '^[0-9]{3}\\.[0-9]{2}$'";
        $stmt6 = $conn->prepare($sql6);
        $stmt6->bind_param("i", $selected_jurnal);
        $stmt6->execute();
        $res6 = $stmt6->get_result();
    } else {
        $sql6 .= " WHERE s.kode_subkategori REGEXP '^[0-9]{3}\\.[0-9]{2}$'";
        $res6 = $conn->query($sql6);
    }
    if ($res6 && $res6->num_rows > 0) {
        while ($row = $res6->fetch_assoc()) { $kegiatan6[] = $row; }
    }

    // Pastikan view menerima semua variabel
    $view_data = [
        'jurnals' => $jurnals,
        'kategori' => $kategori,
        'subkategori' => $subkategori,
        'kegiatan6' => $kegiatan6,
        'selected_jurnal_id' => $selected_jurnal_id
    ];
    
    // Debug sebelum include view
    error_log("Data ke View: " . print_r($view_data, true));
    
    // Include header
    include 'views/header.php';
    
    extract($view_data);
    include 'views/admin_kategori.php';
    
    // Include footer
    include 'views/footer.php';
}



function manageKegiatan() {
    global $conn, $jurnals;
    $selected_jurnal = isset($_GET['id_jurnal']) ? intval($_GET['id_jurnal']) : ($jurnals[0]['id_jurnal'] ?? 0);

    // Ambil kategori pada jurnal terpilih
    $kategori = [];
    $sqlK = "SELECT * FROM kategori WHERE id_jurnal = ? ORDER BY kode_kategori";
    $stmtK = $conn->prepare($sqlK);
    $stmtK->bind_param("i", $selected_jurnal);
    $stmtK->execute();
    $resK = $stmtK->get_result();
    while ($row = $resK->fetch_assoc()) { $kategori[] = $row; }

    // Ambil sub 6-digit pada jurnal terpilih
    $sub6 = [];
    $sqlS = "SELECT s.*, k.kode_kategori, k.nama_kategori FROM subkategori s
             JOIN kategori k ON s.id_kategori = k.id_kategori
             WHERE k.id_jurnal = ? AND s.kode_subkategori REGEXP '^[0-9]{3}\\.[0-9]{2}$'
             ORDER BY k.kode_kategori, s.kode_subkategori";
    $stmtS = $conn->prepare($sqlS);
    $stmtS->bind_param("i", $selected_jurnal);
    $stmtS->execute();
    $resS = $stmtS->get_result();
    while ($row = $resS->fetch_assoc()) { $sub6[] = $row; }

    // Include header
    include 'views/header.php';
    include 'views/manage_kegiatan.php';
    include 'views/footer.php';
}

function saveKegiatan() {
    global $conn;
    $id_jurnal = isset($_POST['id_jurnal']) ? intval($_POST['id_jurnal']) : 0;
    $id_kategori = isset($_POST['id_kategori']) ? intval($_POST['id_kategori']) : 0;
    $id_subkategori = isset($_POST['id_subkategori']) ? intval($_POST['id_subkategori']) : 0;
    $subcode2 = trim($_POST['subcode2'] ?? '');
    $nama = trim($_POST['nama_subkategori'] ?? '');

    if (!$id_kategori || !$id_jurnal || $subcode2 === '' || $nama === '') {
        $_SESSION['error'] = 'Semua field wajib diisi';
        header('Location: admin_kategori.php?action=manage_kegiatan&id_jurnal=' . $id_jurnal);
        exit;
    }

    // Ambil kode kategori (3 digit) dari id_kategori
    $stmt = $conn->prepare("SELECT kode_kategori FROM kategori WHERE id_kategori = ? AND id_jurnal = ?");
    $stmt->bind_param("ii", $id_kategori, $id_jurnal);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    if (!$row) {
        $_SESSION['error'] = 'Kategori tidak valid';
        header('Location: admin_kategori.php?action=manage_kegiatan&id_jurnal=' . $id_jurnal);
        exit;
    }
    $kat3 = $row['kode_kategori'];

    // Normalisasi subcode2 menjadi 2 digit
    if (!preg_match('/^[0-9]{2}$/', $subcode2)) {
        $_SESSION['error'] = 'Subkode harus 2 digit (contoh: 01)';
        header('Location: admin_kategori.php?action=manage_kegiatan&id_jurnal=' . $id_jurnal);
        exit;
    }
    $kode_sub = $kat3 . '.' . $subcode2;

    if ($id_subkategori > 0) {
        // Update
        $sql = "UPDATE subkategori SET kode_subkategori = ?, nama_subkategori = ? WHERE id_subkategori = ?";
        $st = $conn->prepare($sql);
        $st->bind_param("ssi", $kode_sub, $nama, $id_subkategori);
        $ok = $st->execute();
    } else {
        // Insert baru
        // Pastikan unik di kategori yang sama
        $check = $conn->prepare("SELECT 1 FROM subkategori WHERE id_kategori = ? AND kode_subkategori = ?");
        $check->bind_param("is", $id_kategori, $kode_sub);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            $_SESSION['error'] = 'Kode sub 6-digit sudah ada pada kategori ini';
            header('Location: admin_kategori.php?action=manage_kegiatan&id_jurnal=' . $id_jurnal);
            exit;
        }
        $sql = "INSERT INTO subkategori (id_kategori, kode_subkategori, nama_subkategori) VALUES (?, ?, ?)";
        $st = $conn->prepare($sql);
        $st->bind_param("iss", $id_kategori, $kode_sub, $nama);
        $ok = $st->execute();
    }

    if ($ok) {
        $_SESSION['success'] = 'Kegiatan 6-digit disimpan';
    } else {
        $_SESSION['error'] = 'Gagal menyimpan: ' . $conn->error;
    }
    header('Location: admin_kategori.php?action=manage_kegiatan&id_jurnal=' . $id_jurnal);
    exit;
}

function deleteKegiatan6() {
    global $conn;
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    $id_jurnal = isset($_GET['id_jurnal']) ? intval($_GET['id_jurnal']) : 0;
    if (!$id) {
        $_SESSION['error'] = 'ID tidak valid';
        header('Location: admin_kategori.php?action=manage_kegiatan&id_jurnal=' . $id_jurnal);
        exit;
    }
    $sql = "DELETE FROM subkategori WHERE id_subkategori = ?";
    $st = $conn->prepare($sql);
    $st->bind_param("i", $id);
    if ($st->execute()) {
        $_SESSION['success'] = 'Kegiatan 6-digit dihapus';
    } else {
        $_SESSION['error'] = 'Gagal menghapus: ' . $conn->error;
    }
    header('Location: admin_kategori.php?action=manage_kegiatan&id_jurnal=' . $id_jurnal);
    exit;
}
function addKategori() {
    global $jurnals;
    
    // Include header
    include 'views/header.php';
    
    include 'views/form_kategori.php';
    
    // Include footer
    include 'views/footer.php';
}

function addSubkategori() {
    global $conn;
    
    // Ambil data kategori untuk dropdown berdasarkan jurnal yang dipilih (jika ada)
    $selected_jurnal = isset($_GET['id_jurnal']) ? intval($_GET['id_jurnal']) : null;
    
    $kategori = [];
    $sql = "SELECT * FROM kategori";
    
    if ($selected_jurnal) {
        $sql .= " WHERE id_jurnal = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $selected_jurnal);
        $stmt->execute();
        $result = $stmt->get_result();
    } else {
        $result = $conn->query($sql);
    }
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $kategori[] = $row;
        }
    }
    
    // Include header
    include 'views/header.php';
    
    include 'views/form_subkategori.php';
    
    // Include footer
    include 'views/footer.php';
}

function saveKategori() {
    global $conn;
    
    $id_jurnal = intval($_POST['id_jurnal']);
    $kode = trim($_POST['kode_kategori']);
    $nama = trim($_POST['nama_kategori']);
    
    // Validasi
    if (empty($id_jurnal) || empty($kode) || empty($nama)) {
        $_SESSION['error'] = "Semua field harus diisi";
        header("Location: admin_kategori.php?action=add_kategori");
        exit;
    }
    
    // Validasi format kode kategori (3 digit angka)
    if (!preg_match('/^[0-9]{3}$/', $kode)) {
        $_SESSION['error'] = "Kode kategori harus 3 digit angka (contoh: 100, 200, 300)";
        header("Location: admin_kategori.php?action=add_kategori");
        exit;
    }
    
    // Cek apakah kode sudah ada di jurnal yang sama
    $sql = "SELECT id_kategori FROM kategori WHERE kode_kategori = ? AND id_jurnal = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $kode, $id_jurnal);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $_SESSION['error'] = "Kode kategori sudah ada di jurnal ini";
        header("Location: admin_kategori.php?action=add_kategori");
        exit;
    }
    
    // Simpan ke database
    $sql = "INSERT INTO kategori (id_jurnal, kode_kategori, nama_kategori) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $id_jurnal, $kode, $nama);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Kategori berhasil ditambahkan";
    } else {
        $_SESSION['error'] = "Gagal menambahkan kategori: " . $conn->error;
    }
    
    header("Location: admin_kategori.php");
    exit;
}

function saveSubkategori() {
    global $conn;
    
    $id_kategori = intval($_POST['id_kategori']);
    $kode = trim($_POST['kode_subkategori']);
    $nama = trim($_POST['nama_subkategori']);
    
    // Validasi
    if (empty($id_kategori) || empty($kode) || empty($nama)) {
        $_SESSION['error'] = "Semua field harus diisi";
        header("Location: admin_kategori.php?action=add_subkategori");
        exit;
    }
    
    // Validasi format kode subkategori dengan pola yang lebih jelas
    // Format: xxx.xx.xx atau xxx.xx.xxx
    if (!preg_match('/^[0-9]{3}\.[0-9]{2}(\.[0-9]{2,3})?$/', $kode)) {
        $_SESSION['error'] = "Format kode subkategori tidak valid. Harap gunakan pola: xxx.xx.xx atau xxx.xx.xxx (contoh: 100.01.01 atau 200.05.001). Pastikan hanya angka dan titik yang digunakan.";
        header("Location: admin_kategori.php?action=add_subkategori");
        exit;
    }
    
    // Cek apakah kode sudah ada di kategori yang sama
    $sql = "SELECT id_subkategori FROM subkategori WHERE kode_subkategori = ? AND id_kategori = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $kode, $id_kategori);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $_SESSION['error'] = "Kode subkategori sudah ada di kategori ini";
        header("Location: admin_kategori.php?action=add_subkategori");
        exit;
    }
    
    // Simpan ke database
    $sql = "INSERT INTO subkategori (id_kategori, kode_subkategori, nama_subkategori) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $id_kategori, $kode, $nama);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Subkategori berhasil ditambahkan";
    } else {
        $_SESSION['error'] = "Gagal menambahkan subkategori: " . $conn->error;
    }
    
    header("Location: admin_kategori.php");
    exit;
}

function deleteKategori() {
    global $conn;
    
    // Validasi ID
    if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
        $_SESSION['error'] = "ID kategori tidak valid";
        header("Location: admin_kategori.php");
        exit;
    }
    
    $id = intval($_GET['id']);
    
    // Mulai transaksi
    $conn->begin_transaction();
    
    try {
        // 1. Hapus semua subkategori terkait terlebih dahulu
        $sql = "DELETE FROM subkategori WHERE id_kategori = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        
        // 2. Hapus kategori
        $sql = "DELETE FROM kategori WHERE id_kategori = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        
        // Commit transaksi
        $conn->commit();
        
        $_SESSION['success'] = "Kategori dan semua subkategori terkait berhasil dihapus";
    } catch (Exception $e) {
        // Rollback jika ada error
        $conn->rollback();
        $_SESSION['error'] = "Gagal menghapus kategori: " . $e->getMessage();
    }
    
    header("Location: admin_kategori.php");
    exit;
}

function deleteSubkategori() {
    global $conn;
    
    // Validasi ID
    if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
        $_SESSION['error'] = "ID subkategori tidak valid";
        header("Location: admin_kategori.php");
        exit;
    }
    
    $id = intval($_GET['id']);
    
    // 1. Cek apakah subkategori digunakan di transaksi
    $sql = "SELECT COUNT(*) as total FROM transaksi WHERE id_subkategori = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    if ($row['total'] > 0) {
        $_SESSION['error'] = "Tidak dapat menghapus subkategori karena masih digunakan dalam transaksi";
        header("Location: admin_kategori.php");
        exit;
    }
    
    // 2. Hapus subkategori
    $sql = "DELETE FROM subkategori WHERE id_subkategori = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Subkategori berhasil dihapus";
    } else {
        $_SESSION['error'] = "Gagal menghapus subkategori: " . $conn->error;
    }
    
    header("Location: admin_kategori.php");
    exit;
}
?>