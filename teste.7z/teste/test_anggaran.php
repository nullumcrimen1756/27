<?php
require_once 'config.php';
require_once 'functions.php';

echo "<h2>Test Sistem Anggaran Pendapatan</h2>";
echo "<pre>";

// Test 1: Cek Tabel
echo "Test 1: Cek Tabel\n";
$table_exists = $conn->query("SHOW TABLES LIKE 'anggaran_pendapatan'")->num_rows > 0;
if ($table_exists) {
    echo "✅ Tabel anggaran_pendapatan sudah ada\n";
} else {
    echo "❌ Tabel anggaran_pendapatan tidak ada\n";
}

// Test 2: Struktur Tabel
echo "\nTest 2: Struktur Tabel\n";
if ($table_exists) {
    $result = $conn->query("DESCRIBE anggaran_pendapatan");
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "{$row['Field']}\t{$row['Type']}\t{$row['Null']}\t{$row['Key']}\t{$row['Default']}\n";
        }
    }
}

// Test 3: Data Anggaran
echo "\nTest 3: Data Anggaran\n";
if ($table_exists) {
    $result = $conn->query("SELECT * FROM anggaran_pendapatan");
    if ($result->num_rows > 0) {
        echo "ID\tKode\tBulan\tJumlah\tType\n";
        while ($row = $result->fetch_assoc()) {
            echo "{$row['id']}\t{$row['kode_subkategori']}\t{$row['bulan']}\t" . 
                 number_format($row['jumlah'], 2) . "\t{$row['type']}\n";
        }
    } else {
        echo "❌ Tidak ada data anggaran\n";
    }
}

// Test 4: Test Fungsi Save
echo "\nTest 4: Test Fungsi Save\n";
try {
    $testData = [
        'kode_subkategori' => '100.01.01',
        'bulan' => 'All',
        'jumlah' => 1000000,
        'type' => 'subkategori'
    ];
    
    $result = saveAnggaranPendapatan($testData);
    
    if ($result['success']) {
        echo "✅ Test save berhasil: {$result['message']}\n";
    } else {
        echo "❌ Test save gagal: {$result['message']}\n";
    }
} catch (Exception $e) {
    echo "❌ Error test save: " . $e->getMessage() . "\n";
}

// Test 5: Test Update
echo "\nTest 5: Test Update\n";
try {
    $testData = [
        'kode_subkategori' => '100.01.01',
        'bulan' => 'All',
        'jumlah' => 2000000, // Update nilai
        'type' => 'subkategori'
    ];
    
    $result = saveAnggaranPendapatan($testData);
    
    if ($result['success']) {
        echo "✅ Test update berhasil: {$result['message']}\n";
        
        // Verifikasi update
        $verify = $conn->query("SELECT jumlah FROM anggaran_pendapatan WHERE kode_subkategori = '100.01.01'");
        if ($verify->num_rows > 0) {
            $row = $verify->fetch_assoc();
            echo "✅ Nilai terupdate: " . number_format($row['jumlah'], 2) . "\n";
        }
    } else {
        echo "❌ Test update gagal: {$result['message']}\n";
    }
} catch (Exception $e) {
    echo "❌ Error test update: " . $e->getMessage() . "\n";
}

echo "</pre>";
?>
