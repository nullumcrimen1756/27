<?php
session_start();

// Ambil parameter filter yang sama dengan laporan
$selected_jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : '';
$selected_tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');
$search_keyword = isset($_GET['search']) ? trim($_GET['search']) : '';

// Validasi session dan data
if (!isset($_SESSION['sheet2_report']) || empty($_SESSION['sheet2_report'])) {
    die("Tidak ada data laporan untuk diexport.");
}

$report = $_SESSION['sheet2_report'];
$daftar_jurnal = isset($_SESSION['daftar_jurnal']) ? $_SESSION['daftar_jurnal'] : [];

// Filter data sesuai dengan parameter yang dipilih (sama seperti di laporan)
if ($selected_jurnal_filter && isset($daftar_jurnal[$selected_jurnal_filter])) {
    $selected_jurnal_name = $daftar_jurnal[$selected_jurnal_filter];
    if (isset($report[$selected_jurnal_name])) {
        $filtered_report = [$selected_jurnal_name => $report[$selected_jurnal_name]];
        $report = $filtered_report;
    } else {
        $report = [];
    }
}

if (!empty($search_keyword)) {
    $filtered_report = [];
    foreach ($report as $jurnal => $bulan_data) {
        $filtered_bulan_data = [];
        foreach ($bulan_data as $bulan => $subkategori_data) {
            $filtered_subkategori_data = [];
            foreach ($subkategori_data as $subkategori => $data) {
                $filtered_transactions = [];
                foreach ($data['transactions'] as $trans) {
                    if (stripos($trans['no_kwitansi'], $search_keyword) !== false || 
                        stripos($trans['uraian'], $search_keyword) !== false) {
                        $filtered_transactions[] = $trans;
                    }
                }
                if (!empty($filtered_transactions)) {
                    $filtered_subkategori_data[$subkategori] = [
                        'kategori' => $data['kategori'],
                        'transactions' => $filtered_transactions,
                        'total' => array_sum(array_column($filtered_transactions, 'jumlah'))
                    ];
                }
            }
            if (!empty($filtered_subkategori_data)) {
                $filtered_bulan_data[$bulan] = $filtered_subkategori_data;
            }
        }
        if (!empty($filtered_bulan_data)) {
            $filtered_report[$jurnal] = $filtered_bulan_data;
        }
    }
    $report = $filtered_report;
}

// Set header untuk download file Excel (HTML-based)
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=\"Laporan_Sheet2_" . date('Ymd_His') . ".xls\"");
header("Pragma: no-cache");
header("Expires: 0");
?>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; }
        .title { font-size: 16pt; font-weight: bold; text-align: center; margin-bottom: 20px; color: #1F4E78; }
        .info-label { font-weight: bold; width: 100px; background-color: #E6E6E6; padding: 4px 8px; border: 1px solid #CCC; }
        .info-value { padding: 4px 8px; border: 1px solid #CCC; }
        .table { border-collapse: collapse; width: 100%; margin-bottom: 15px; }
        .table th { background-color: #4472C4; color: white; font-weight: bold; text-align: center; padding: 8px; border: 1px solid #000; }
        .table td { padding: 6px; border: 1px solid #000; }
        .total-row { background-color: #D9E1F2; font-weight: bold; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .jurnal-header { font-size: 12pt; font-weight: bold; margin-top: 20px; margin-bottom: 10px; color: #305496; background-color: #E6F0FF; padding: 8px; border-left: 4px solid #305496; }
        .bulan-header { font-weight: bold; margin-top: 15px; margin-bottom: 8px; color: #548235; padding: 6px; background-color: #E2EFDA; border-left: 3px solid #548235; }
        .subkategori-header { font-style: italic; margin-top: 10px; margin-bottom: 5px; color: #823535; padding: 5px; background-color: #FCE4D6; border-left: 2px solid #823535; }
        .info-table { border-collapse: collapse; margin-bottom: 20px; }
        .info-table td { padding: 5px; border: 1px solid #CCC; }
    </style>
    <title>Laporan Terstruktur (Sheet 2)</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
    <div class="title">LAPORAN TERSTRUKTUR (SHEET 2)</div>
    <table class="info-table">
        <?php if ($selected_jurnal_filter && isset($daftar_jurnal[$selected_jurnal_filter])): ?>
        <tr>
            <td class="info-label">Jurnal:</td>
            <td class="info-value"><?= htmlspecialchars($daftar_jurnal[$selected_jurnal_filter]) ?></td>
        </tr>
        <?php endif; ?>
        <?php if ($selected_tahun_filter): ?>
        <tr>
            <td class="info-label">Tahun:</td>
            <td class="info-value"><?= $selected_tahun_filter ?></td>
        </tr>
        <?php endif; ?>
        <?php if ($search_keyword): ?>
        <tr>
            <td class="info-label">Pencarian:</td>
            <td class="info-value"><?= htmlspecialchars($search_keyword) ?></td>
        </tr>
        <?php endif; ?>
        <tr>
            <td class="info-label">Tanggal Export:</td>
            <td class="info-value"><?= date('d-m-Y H:i:s') ?></td>
        </tr>
    </table>

    <?php if (!empty($report)): ?>
        <?php foreach ($report as $jurnal => $bulan_data): ?>
            <div class="jurnal-header">JURNAL: <?= htmlspecialchars($jurnal) ?></div>
            <?php foreach ($bulan_data as $bulan => $subkategori_data): ?>
                <div class="bulan-header"><?= htmlspecialchars(strtoupper($bulan)) ?></div>
                <?php foreach ($subkategori_data as $subkategori => $data): ?>
                    <div class="subkategori-header"><?= htmlspecialchars($subkategori) ?> (<?= htmlspecialchars($data['kategori']) ?>)</div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th width="15%">Tanggal</th>
                                <th width="20%">No. Kwitansi</th>
                                <th width="45%">Uraian</th>
                                <th width="20%">Jumlah</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($data['transactions'] as $trans): ?>
                                <tr>
                                    <td class="text-center"><?= date('d-m-Y', strtotime($trans['tanggal'])) ?></td>
                                    <td><?= htmlspecialchars($trans['no_kwitansi']) ?></td>
                                    <td><?= htmlspecialchars($trans['uraian']) ?></td>
                                    <td class="text-right">Rp <?= number_format($trans['jumlah'], 0, ',', '.') ?></td>
                                </tr>
                            <?php endforeach; ?>
                            <tr class="total-row">
                                <td colspan="3" class="text-right">Total</td>
                                <td class="text-right">Rp <?= number_format($data['total'], 0, ',', '.') ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <br>
                <?php endforeach; ?>
                <br>
            <?php endforeach; ?>
        <?php endforeach; ?>
    <?php else: ?>
        <p style="color: #FF0000; font-weight: bold; font-style: italic;">Tidak ada data yang cocok dengan filter yang dipilih.</p>
    <?php endif; ?>
</body>
</html>


